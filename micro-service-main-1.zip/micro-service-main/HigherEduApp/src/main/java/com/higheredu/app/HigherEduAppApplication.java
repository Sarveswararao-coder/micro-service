package com.higheredu.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HigherEduAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HigherEduAppApplication.class, args);
	}

}
